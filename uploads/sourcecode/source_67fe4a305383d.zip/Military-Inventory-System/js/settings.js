// Settings dropdown functionality
document.addEventListener('DOMContentLoaded', function() {
    // Get the settings toggle and dropdown elements
    const settingsToggle = document.getElementById('settings-toggle');
    const settingsDropdown = document.getElementById('settings-dropdown');
    
    // Toggle the settings dropdown when the settings icon is clicked
    if (settingsToggle) {
        settingsToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            settingsDropdown.style.display = settingsDropdown.style.display === 'block' ? 'none' : 'block';
        });
    }
    
    // Close the dropdown when clicking outside of it
    document.addEventListener('click', function(e) {
        if (settingsDropdown && settingsDropdown.style.display === 'block' && !settingsToggle.contains(e.target)) {
            settingsDropdown.style.display = 'none';
        }
    });
    
    // Handle the settings options clicks
    const settingsOptions = document.querySelectorAll('.settings-option');
    settingsOptions.forEach(option => {
        option.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            // Close the dropdown
            if (settingsDropdown) {
                settingsDropdown.style.display = 'none';
            }
            
            // Handle different actions
            switch(action) {
                case 'add-user':
                    window.location.href = 'register_user.html';
                    break;
                case 'manage-users':
                    window.location.href = 'manage_users.html';
                    break;
                case 'access-control':
                    window.location.href = 'access_control.html';
                    break;
                case 'system-settings':
                    window.location.href = 'system_settings.html';
                    break;
                case 'security-settings':
                    window.location.href = 'security_settings.html';
                    break;
                case 'logout':
                    window.location.href = 'index.html';
                    break;
                default:
                    console.log('Unknown action:', action);
            }
        });
    });
}); 