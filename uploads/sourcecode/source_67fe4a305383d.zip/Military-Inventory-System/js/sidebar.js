// Load sidebar
document.addEventListener('DOMContentLoaded', function() {
    // First load the sidebar HTML
    fetch('includes/sidebar.html')
        .then(response => response.text())
        .then(data => {
            // Insert the sidebar HTML at the beginning of the body
            const mainContentDiv = document.getElementById('main-content');
            if (mainContentDiv) {
                mainContentDiv.insertAdjacentHTML('beforebegin', data);
            }
            
            // Add sidebar CSS if not already present
            if (!document.querySelector('style#sidebar-styles')) {
                const sidebarStyles = document.createElement('style');
                sidebarStyles.id = 'sidebar-styles';
                sidebarStyles.textContent = `
                    /* Sidebar styles */
                    .sidebar {
                        width: 250px;
                        height: 100%;
                        position: fixed;
                        top: 0;
                        left: 0;
                        background-color: white;
                        transition: all 0.3s;
                        z-index: 30;
                        box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
                    }
                    .sidebar.collapsed {
                        transform: translateX(-250px);
                    }
                    .sidebar-menu-item {
                        display: flex;
                        align-items: center;
                        padding: 12px 20px;
                        color: #64748b;
                        transition: all 0.2s;
                    }
                    .sidebar-menu-item:hover {
                        background-color: #f1f5f9;
                        color: #1a56db;
                    }
                    .sidebar-menu-item.active {
                        color: #1a56db;
                        background-color: #eff6ff;
                        border-right: 3px solid #1a56db;
                        font-weight: 500;
                    }
                    .sidebar-menu-icon {
                        margin-right: 12px;
                    }
                    .main-content {
                        transition: all 0.3s;
                        margin-left: 250px;
                    }
                    .main-content.expanded {
                        margin-left: 0;
                    }
                    @media (max-width: 768px) {
                        .sidebar {
                            transform: translateX(-250px);
                        }
                        .sidebar.expanded {
                            transform: translateX(0);
                        }
                        .main-content {
                            margin-left: 0;
                        }
                    }
                    .overlay {
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background-color: rgba(0, 0, 0, 0.3);
                        z-index: 20;
                        display: none;
                    }
                    .overlay.active {
                        display: block;
                    }
                `;
                document.head.appendChild(sidebarStyles);
            }

            // Make sure main content div has the correct class and margin
            const mainContent = document.getElementById('main-content');
            if (mainContent && !mainContent.classList.contains('main-content')) {
                mainContent.classList.add('main-content');
            }
        });
}); 